# .Net Covid Desktop App

Covid Desktop APP
By Aretas Zarnauskas and Dovydas Viskontas 
